const os = require("os");

console.log("Operating system name: " + os.type());

console.log("OS release : " + os.release());
